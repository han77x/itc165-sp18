package com.example.a009x.broadcastdemo;


public class DbContract {
    public static final String TABLE_NAME ="incomingInfo";
    public static final String INCOMING_NUMBER ="incomingNumber";
    public static final String UPDATE_UI_FILTER = "com.example.a009x.broadcastdemo.UPDATE_UI";

}
